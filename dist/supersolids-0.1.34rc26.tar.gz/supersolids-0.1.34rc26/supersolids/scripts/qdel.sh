#!/usr/bin/env bash
start=8110
job_number=15

for ((i = $start; i < $((start + job_number)); i++))
do
	scancel $i
done

