#!/usr/bin/env python

import numpy as np
from scipy.special import j0

from supersolids.helper import functions


# Dipolar interaction
def Udd(r, z):
    return (r**2 - 2 * z**2)/(r**2 + z**2)**2.5


# Integrand of the last line of the explicit form of the Fourier transform
def integrand(r, z, kr, kz):
    result = np.cos(kz * z) * Udd(r, z) * j0(kr * r) * r
    return result


# Explicit calculation of the Fourier transform with the cylindrical cut-off
def Vdk(kr, kz, r, z, dr, dz, z_coff):
    k2 = kr**2 + kz**2
    cos2a = kz**2/k2
    sin2a = 1 - cos2a
    sinacosa = np.sqrt(sin2a * cos2a)
    term1 = cos2a - 1./3. 
    term2 = np.exp(-z_coff * kr) * (sin2a*np.cos(z_coff * kz) - sinacosa * np.sin(z_coff * kz))
    term3 = -np.sum(np.sum(integrand(r[:, np.newaxis], z, kr, kz), axis=0)) * dr * dz
    return (term1 + term2 + term3) * 4 * np.pi


# Formation of the r and z grids
def get_rz(params_rz):
    nr_max, nz_max, r_coff, z_coff, r_max_factor = params_rz
    r_max = r_max_factor * r_coff
    dz, dr = z_coff/nz_max, (r_max - r_coff)/nr_max # Spatial steps
    return np.linspace(0, z_coff, nz_max), np.linspace(r_coff, r_max, nr_max), dr, dz


if __name__ == "__main__":
    # SPATIAL GRID
    # params = (nr_max, nz_max, r_coff, z_coff, r_max_factor)
    # nr_max, nz_max: number of points along r,z
    # r_coff, z_coff: radial and axial cutoff
    # maximal r for the integration: rmax=r_max_factor*r_coff

    # For the cut-off I would conservatively choose half of the numerical box in each direction

    nr_max, nz_max, r_coff, z_coff, r_max_factor = 12000, 32, 5, 3, 200
    params_rz = (nr_max, nz_max, r_coff, z_coff, r_max_factor)
    z, r, dr, dz = get_rz(params_rz)

    # TEST
    kr0 = 0.0
    kz0 = 0.000001
    with functions.run_time(name=f"sum"):
        result = np.sum(np.sum(integrand(r[:, np.newaxis], z, kr0, kz0), axis=0)) * dr * dz

    print(f"result: {result}")


