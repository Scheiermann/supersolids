#!/usr/bin/env python

import numpy as np
import time


def psi_gauss_3d(x, y, z,
                 a_x: float = 1.0, a_y: float = 1.0, a_z: float = 1.0,
                 x_0: float = 0.0, y_0: float = 0.0, z_0: float = 0.0,
                 k_0: float = 0.0):
    """
    Gaussian wave packet of width a and momentum k_0, centered at x_0

    :param x: mathematical variable

    :param y: mathematical variable

    :param z: mathematical variable

    :param a_x: Stretching factor in x direction (np.sqrt(2) * std_deviation)

    :param a_y: Stretching factor in y direction (np.sqrt(2) * std_deviation)

    :param a_z: Stretching factor in z direction (np.sqrt(2) * std_deviation)

    :param x_0: Mean spatial x of pulse

    :param y_0: Mean spatial y of pulse

    :param z_0: Mean spatial z of pulse

    :param k_0: Group velocity of pulse

    """

    return ((a_x * a_y * a_z * np.pi ** (3.0 / 2.0)) ** -0.5
            * np.exp(-0.5 * (
                    ((x - x_0) / a_x) ** 2.0
                    + ((y - y_0) / a_y) ** 2.0
                    + ((z - z_0) / a_z) ** 2.0)
                     + 1j * x * k_0))


if __name__ == "__main__":
    res_x = 512
    res_y = 512
    res_z = 512

    x0 = -10.0
    x1 = 10.0
    y0 = -8.0
    y1 = 8.0
    z0 = -4.0
    z1 = 4.0

    xxx, yyy, zzz = np.mgrid[x0: x1: complex(0, res_x),
                             y0: y1: complex(0, res_y),
                             z0: z1: complex(0, res_z)]

    gauss_x_3d = psi_gauss_3d(x=xxx, y=yyy, z=zzz,
                              a_x=2.0, a_y=1.5, a_z=1.2)

    start: float = time.perf_counter()
    gauss_k_3d = np.fft.fftn(gauss_x_3d)
    lol = np.fft.ifftn(gauss_x_3d)
    time_measured: float = time.perf_counter() - start
    print(f"Runtime {time_measured:.8f} s")
