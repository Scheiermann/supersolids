'''

TWO-COMPONENT 3D GP EQUATION WITH CONTACT AND DIPOLAR INTERACTIONS AND LHY

Version of Oct. 12, 2021
Added the calculation of the contrast and of the energy

'''

import numpy as np
from scipy.integrate import quad
from scipy import interpolate
import time, pickle
import matplotlib.pyplot as plt
from scipy.fft import fftn, ifftn, fftfreq, fftshift

########################################################################################

# Creation of a 1D array, and spatial step
def create_1D_array(xmax, nxmax):
    dx = 2 * xmax/nxmax
    return dx, np.linspace(-xmax, xmax - dx, nxmax)

# Creation of the 3D array, and the spatial steps
def create_3D_array(xmax, ymax, zmax, nxmax, nymax, nzmax):
    dx, x = create_1D_array(xmax, nxmax)
    dy, y = create_1D_array(ymax, nymax)
    dz, z = create_1D_array(zmax, nzmax)
    return dx, dy, dz, np.meshgrid(x, y, z, indexing='ij')

########################################################################################

# Trap energy (harmonic oscillator)
def V_tr(xv, yv, zv, lHO, ay, az):
    return (xv**2 + ay**2 * yv**2 + az**2 * zv**2)/(2. * lHO**4)

# Kinetic energy
def T(xfv, yfv, zfv):
    return (xfv**2 + yfv**2 + zfv**2)/2.

########################################################################################

# Fourier transform of the dipolar potential (NO CUTOFF FOR THE MOMENT)
@np.vectorize
def Vdd(kx, ky, kz):
    if (kx**2 + ky**2 + kz**2)==0: # We avoid the problematic k=0 point, which is anyway irrelevant
        return 0.
    else:
        kr=np.sqrt(kx**2 + ky**2)
        cos2a = kz**2/(kr**2 + kz**2)
        return 4. * np.pi * (cos2a - 1./3.) # (4 pi/3) (3 cos^2 theta_k - 1)
    
########################################################################################
        
# Plot of the column density (integrated along z) 
#(Note: actually it would need to be multiplied by dz in order to be the integral, but it does not matter much)
def depictxy(dens, xmax, ymax, nxmax, nymax, nzmax, l_unit):
    densxy = np.sum(dens, axis=2)
    dx, x = create_1D_array(xmax, nxmax)
    dy, y = create_1D_array(ymax, nymax)
    xv, yv = np.meshgrid(x, y, indexing='ij') 
    plt.axis('equal')
    plt.pcolormesh(y, x, densxy)
    plt.show()        

########################################################################################

# Functions for the creation of the LHY chemical potential for two components, 
# and for the calculation of the LHY energy density

def V(lam, eta_aa, eta_bb, eta_ab, A): # This is the V function in Eq. (3) of [PRL 126, 025301 (2021)]
    return (eta_aa * A  + eta_bb * (1 - A) + 
            lam * np.sqrt((eta_aa * A   - eta_bb * (1 - A))**2 + 4 * eta_ab**2 * A * (1 - A)))

def dVdna(lam, eta_aa, eta_bb, eta_ab, A): # dV/dna
    return (eta_aa + lam * (eta_aa * (eta_aa * A - eta_bb * (1 - A)) + 2 * eta_ab**2 * (1 - A))/
                     np.sqrt((eta_aa * A - eta_bb * (1 - A))**2 + 4 * eta_ab**2 * A * (1 - A)))

def dVdnb(lam, eta_aa, eta_bb, eta_ab, A): # dV/dnb
    return (eta_bb + lam * (eta_bb * (eta_bb * (1 - A) - eta_aa * A) + 2 * eta_ab**2 * A)/
                     np.sqrt((eta_aa * A - eta_bb * (1 - A))**2 + 4 * eta_ab**2 * A * (1 - A)))

def func_a(u, g_aa, g_bb, g_ab, gd_aa, gd_bb, gd_ab, A): # (V_+)**3/2 dV_+/dna + (V_-)**3/2 dV_-/dna
    eta_aa = g_aa + gd_aa * 4. * np.pi * (u**2 - 1./3.)
    eta_bb = g_bb + gd_bb * 4. * np.pi * (u**2 - 1./3.)
    eta_ab = g_ab + gd_ab * 4. * np.pi * (u**2 - 1./3.)    
    term1 = np.lib.scimath.sqrt(V(1, eta_aa, eta_bb, eta_ab, A))**3. * dVdna(1, eta_aa, eta_bb, eta_ab, A)
    term2 = np.lib.scimath.sqrt(V(-1, eta_aa, eta_bb, eta_ab, A))**3. * dVdna(-1, eta_aa, eta_bb, eta_ab, A)
    return np.real(term1 + term2)

def func_b(u, g_aa, g_bb, g_ab, gd_aa, gd_bb, gd_ab, A): # (V_+)**3/2 dV_+/dnb + (V_-)**3/2 dV_-/dnb
    eta_aa = g_aa + gd_aa * 4. * np.pi * (u**2 - 1./3.)
    eta_bb = g_bb + gd_bb * 4. * np.pi * (u**2 - 1./3.)
    eta_ab = g_ab + gd_ab * 4. * np.pi * (u**2 - 1./3.)
    term1 = np.lib.scimath.sqrt(V(1, eta_aa, eta_bb, eta_ab, A))**3. * dVdnb(1, eta_aa, eta_bb, eta_ab, A)
    term2 = np.lib.scimath.sqrt(V(-1, eta_aa, eta_bb, eta_ab, A))**3. * dVdnb(-1, eta_aa, eta_bb, eta_ab, A)
    return np.real(term1 + term2)

def func_ep(u, g_aa, g_bb, g_ab, gd_aa, gd_bb, gd_ab, A): # (V_+)**5/2 + (V_-)**5/2
    eta_aa = g_aa + gd_aa * 4. * np.pi * (u**2 - 1./3.)
    eta_bb = g_bb + gd_bb * 4. * np.pi * (u**2 - 1./3.)
    eta_ab = g_ab + gd_ab * 4. * np.pi * (u**2 - 1./3.)    
    return np.real(np.lib.scimath.sqrt(V(1, eta_aa, eta_bb, eta_ab, A))**5. 
            + np.lib.scimath.sqrt(V(-1, eta_aa, eta_bb, eta_ab, A))**5.)

@np.vectorize
def ep_LHY(A, g_aa, g_bb, g_ab, gd_aa, gd_bb, gd_ab): # Eq. (4) in [PRL 126, 025301 (2021)]
    args = (g_aa, g_bb, g_ab, gd_aa, gd_bb, gd_ab, A)
    prefactor = np.sqrt(2.)/15./np.pi**2    
    return prefactor * quad(func_ep, 0., 1., args=args)[0]

@np.vectorize
def mu_a(A, g_aa, g_bb, g_ab, gd_aa, gd_bb, gd_ab): # d/dna of Eq. (4) in [PRL 126, 025301 (2021)]
    args = (g_aa, g_bb, g_ab, gd_aa, gd_bb, gd_ab, A)
    prefactor = 1./3./np.pi**2/np.sqrt(2.)    
    return prefactor * quad(func_a, 0., 1., args=args)[0]

@np.vectorize
def mu_b(A, g_aa, g_bb, g_ab, gd_aa, gd_bb, gd_ab): # d/dnb of Eq. (4) in [PRL 126, 025301 (2021)]
    args = (g_aa, g_bb, g_ab, gd_aa, gd_bb, gd_ab, A)
    prefactor = 1./3./np.pi**2/np.sqrt(2.)
    return prefactor * quad(func_b, 0., 1., args=args)[0]


########################################################################################################

# Contrast of the droplets (only works now for 1D arrays)
# We evaluate the density along the x axis only between Nx/2 - Nx/16 and Nx/2 + Nx/16
def contrast(dens_a, dens_b, nxmax, nymax, nzmax):
    dens_a_x_cut = dens_a[nxmax//2 - nxmax//16 : nxmax//2 + nxmax//16, nymax//2, nzmax//2]
    dens_b_x_cut = dens_b[nxmax//2 - nxmax//16 : nxmax//2 + nxmax//16, nymax//2, nzmax//2]
    dens_a_min = np.min(dens_a_x_cut)
    dens_a_max = np.max(dens_a_x_cut)
    dens_b_min = np.min(dens_b_x_cut)
    dens_b_max = np.max(dens_b_x_cut)
    contrast_a = (dens_a_max - dens_a_min)/(dens_a_max + dens_a_min)
    contrast_b = (dens_b_max - dens_b_min)/(dens_b_max + dens_b_min)
    return contrast_a, contrast_b

########################################################################
########################################################################
########################################################################

# General constants
i = 1.           # set to i=1 for the imaginary time evolution
EPS = 1.e-16     # Accuracy for the imaginary time evolution (convergence of chemical potential)
hbar = 1.05e-34  # hbar
amu = 1.66e-27   # Atomic mass unit
a0 = 0.529e-10   # Bohr magneton

########################################################################

# Physical parameters

str_Species = "_Dy_Dy9_"
mass = 163.9 * amu                # mass of Dy
if str_Species == "_Dy_Dy9_":
    dip_b = 9./10.       # dipole moment of b divided by dipole moment of a (a = Dysprosium, b = Dysprosium s=9)
else:
    if str_Species == "_Dy_Er_":
        dip_b = 7./10.       # dipole moment of b divided by dipole moment of a (a = Dysprosium, b = Erbium)
    else:
        dip_b = 1. # dipole moment of b divided by dipole moment of a (a = Dysprosium, b = Dysprosium)        

        asc_aa = 95.0 * a0                # scattering length aa
asc_bb = asc_aa                   # scattering length bb
asc_ab = 0.80 * asc_aa            # scattering length ab


add_aa = 130.8 * a0               # dipolar length aa (of 164Dy)
add_bb = dip_b**2 * add_aa        # dipolar length bb
add_ab = dip_b * add_aa           # dipolar length ab

N_atoms_tot = 6.3e4   # Total number of atoms
B_Ratio = 0.4         # N_B = N_TOT * B_Ratio; B_Ratio = 0 => only A, B_ratio = 0.5 => equal admixture

N_atoms_a = (1 - B_Ratio) * N_atoms_tot       # Number of atoms in A
N_atoms_b = B_Ratio * N_atoms_tot             # Number of atoms in B

fx = 33.0                         # frequency x (in Hz)
fy = 110.0                        # frequency y
fz = 167.0                        # frequency z

########################################################################

# Parameters of the numerics

tmax = 10.                # maximal time considered (I use x-harmonic oscillator units)
dt = 0.0002               # time step
nxmax, xmax = 128, 12.    # x number of points; the grid goes from -xmax to xmax
nymax, ymax = 64, 6.      # y number of points; the grid goes from -ymax to ymax
nzmax, zmax = 32, 6.      # z number of points; the grid goes from -zmax to zmax

########################################################################

lHO_x = np.sqrt(hbar/mass/(2.0 * np.pi * fx)) # x harmonic oscillator length
ay, az = fy/fx, fz/fx                         # frequency ratios
l_unit = lHO_x                                # unit of length = harmonic oscillator length; 
                                              # the unit of frequency is hbar/mass/l_unit^2
    
# Note that the number of atoms is not in the coupling constant but rather in the density    
g_aa = 4 * np.pi * asc_aa/l_unit              # coupling constant aa
g_bb = 4 * np.pi * asc_bb/l_unit              # coupling constant bb
g_ab = 4 * np.pi * asc_ab/l_unit              # coupling constant ab
gd_aa = 3 * add_aa/l_unit                     # dipole coupling constant  aa
gd_bb = 3 * add_bb/l_unit                     # dipole coupling constant  bb
gd_ab = 3 * add_ab/l_unit                     # dipole coupling constant  ab

lHO = lHO_x/l_unit                            # now lHO=1 (the unit)

########################################################################################################

# Interpolation functions to evaluate the LHY chemical potential
# Let n1 + n2 = n, and n1= A n, then mu_(s=a,b)(n1,n2)=n**1.5 * f_s(A), and energy_lhy = n**2.5 ep(A)
# Here we obtain the interpolation functions f_s(A) and ep(A); note that A=0,...,1
nA_max = 100
A_v = np.linspace(0, 1, nA_max)
mu_a_v = mu_a(A_v, g_aa, g_bb, g_ab, gd_aa, gd_bb, gd_ab)
mu_b_v = mu_b(A_v, g_aa, g_bb, g_ab, gd_aa, gd_bb, gd_ab)
ep_LHY_v = ep_LHY(A_v, g_aa, g_bb, g_ab, gd_aa, gd_bb, gd_ab)
f_a = interpolate.interp1d(A_v, mu_a_v)
f_b = interpolate.interp1d(A_v, mu_b_v)
ep = interpolate.interp1d(A_v, ep_LHY_v)


########################################################################################################

# Creation of the spatial grid
dx, dy, dz, (xv, yv, zv) = create_3D_array(xmax, ymax, zmax, nxmax, nymax, nzmax)

# Trap energy
V_trap = V_tr(xv, yv, zv, lHO, ay, az)

# Grid in momentum
xf, yf, zf = fftfreq(nxmax, dx) * 2 * np.pi, fftfreq(nymax, dy) * 2 * np.pi, fftfreq(nzmax, dz) * 2 * np.pi
xfv, yfv, zfv = np.meshgrid(xf, yf, zf, indexing='ij')

# Kinetic energy
E_kin = T(xfv, yfv, zfv)

# Dipolar energy
Udd = Vdd(xfv, yfv, zfv)

########################################################################

# Initial condition: Gaussian times some random noise (normalized to 1)
lini = 3.0

psi_a = np.exp(-(xv**2 + yv**2 + zv**2)/2./lini**2) * (1. + 0.05 * np.random.rand(nxmax,nymax,nzmax))
norm_a = np.sum(np.abs(psi_a)**2) * dx * dy * dz
psi_a /= np.sqrt(norm_a)

psi_b = np.exp(-(xv**2 + yv**2 + zv**2)/2./lini**2)* (1. + 0.05 * np.random.rand(nxmax,nymax,nzmax))
norm_b = np.sum(np.abs(psi_b)**2) * dx * dy * dz
psi_b /= np.sqrt(norm_b)

########################################################################

# Time evolution
chem_pot_old_a, chem_pot_old_b, chem_pot_rel = 1000., 1000., 1000.  # just something large for the beginning
chem_pot_a, chem_pot_b = 0., 0.            # just to initiate the variables chem_pot_a and chem_pot_b

t = 0.              # initialization of the time
t_dep = 0           # initialization of the depicting time
t_dep_step = 0.01   # We get data every t_dep_step

while chem_pot_rel > EPS and t < tmax: # Go on with the time evolution until convergence of the chem. pot. or tmax reached
    
    dens_a = np.abs(psi_a)**2 * N_atoms_a       # density of A
    dens_b = np.abs(psi_b)**2 * N_atoms_b       # density of B    
    dens = dens_a + dens_b                      # Total density
    A = dens_a/dens                             # A = n1/(n1+n2)
    mu_LHY_a = f_a(A) * dens**1.5               # mu_LHY_A
    mu_LHY_b = f_b(A) * dens**1.5               # mu_LHY_B    
    Udd_a = np.real(ifftn(Udd * fftn(dens_a)))  # The dipolar potential Udd_a(r)
    Udd_b = np.real(ifftn(Udd * fftn(dens_b)))  # The dipolar potential Udd_b(r)
    
    if t>=t_dep: # We depict the column density on the xy plane, and get the energy every t_de_step
                 # We extract the time, the relative change in chem. pot., 
                 # the chem. pot., the energy, and the running time
        depictxy(dens_a, xmax, ymax, nxmax, nymax, nzmax, l_unit) # Plot of the column density of component A
        depictxy(dens_b, xmax, ymax, nxmax, nymax, nzmax, l_unit) # Plot of the column density of component B    
        t_dep += t_dep_step
        contrast_a, contrast_b = contrast(dens_a, dens_b, nxmax, nymax, nzmax) # contrast_a and contrast_b        
        En_LHY = ep(A) * dens**2.5                                             # LHY energy density
        # Calculation of the energy per atom using the chemical potentials 
        # (in this way we don't need to evaluate the kinetic energy again)
        Energy = (chem_pot_a * N_atoms_a + chem_pot_b * N_atoms_b + 
                  - np.sum(0.5 * g_aa * dens_a**2 + 0.5 * g_bb * dens_b**2 + g_ab * dens_a * dens_b
                          + 0.5 * gd_aa * Udd_a * dens_a + 0.5 * gd_bb * Udd_b * dens_b 
                          + 0.5 * gd_ab * Udd_a * dens_b + 0.5 * gd_ab * Udd_b * dens_a
                          - En_LHY + mu_LHY_a * dens_a + mu_LHY_b * dens_b) * dx * dy * dz) / (N_atoms_a + N_atoms_b)
        print(f't = {t}, mu_rel = {chem_pot_rel}, Energy = {Energy}, contr_a = {contrast_a}, contr_b = {contrast_b}\n')
    
    # Time evolution: Trotter in 2nd order
    psi_a = (ifftn(np.exp(-i * E_kin * dt) * 
                 fftn(np.exp(-i * (V_trap + g_aa * dens_a + g_ab * dens_b +
                                   gd_aa * Udd_a + gd_ab * Udd_b + mu_LHY_a) * dt/2) * psi_a)))  # Evolution of A
    psi_b = (ifftn(np.exp(-i * E_kin * dt) * 
                 fftn(np.exp(-i * (V_trap + g_bb * dens_b + g_ab * dens_a +
                                   gd_bb * Udd_b + gd_ab * Udd_a + mu_LHY_b) * dt/2) * psi_b)))  # Evolution of B
    
    dens_a = np.abs(psi_a)**2 * N_atoms_a       # density of A
    dens_b = np.abs(psi_b)**2 * N_atoms_b       # density of B    
    dens = dens_a + dens_b                      # Total density
    A = dens_a/dens                             # A = n1/(n1+n2)
    mu_LHY_a = f_a(A) * dens**1.5               # mu_LHY_A
    mu_LHY_b = f_b(A) * dens**1.5               # mu_LHY_B
    Udd_a = np.real(ifftn(Udd * fftn(dens_a)))      # The dipolar potential Udd_a(r)
    Udd_b = np.real(ifftn(Udd * fftn(dens_b)))      # The dipolar potential Udd_b(r)
    psi_a = np.exp(-i * (V_trap + g_aa * dens_a + g_ab * dens_b +
                                   gd_aa * Udd_a + gd_ab * Udd_b + mu_LHY_a) * dt/2) * psi_a  # Evolution of A

    psi_b = np.exp(-i * (V_trap + g_bb * dens_b + g_ab * dens_a +
                                   gd_bb * Udd_b + gd_ab * Udd_a + mu_LHY_b) * dt/2) * psi_b  # Evolution of B
    
    
    # Re-normalization of the wavefunction of components A and B
    norm_a = np.sum(np.abs(psi_a)**2) * dx * dy * dz
    psi_a /= np.sqrt(norm_a)
    norm_b = np.sum(np.abs(psi_b)**2) * dx * dy * dz
    psi_b /= np.sqrt(norm_b)
    
    # Evaluation of the chemical potential
    chem_pot_a = -np.log(norm_a)/(2.*dt)  # Calculation of the chemical potential of the A component
    chem_pot_b = -np.log(norm_b)/(2.*dt)  # Calculation of the chemical potential of the B component
    
    chem_pot_rel_a = np.abs((chem_pot_a - chem_pot_old_a)/chem_pot_a) # Relative change of chem. pot. of component A
    chem_pot_rel_b = np.abs((chem_pot_b - chem_pot_old_b)/chem_pot_b) # Relative change of chem. pot. of component A
    
    chem_pot_rel = max(chem_pot_rel_a, chem_pot_rel_b) # We take the maximal change for the covergence check
    
    chem_pot_old_a = chem_pot_a # Update of the chem. pot. of A for comparison in the next step
    chem_pot_old_b = chem_pot_b # Update of the chem. pot. of A for comparison in the next step
    
    # Advance the time a time-step
    t += dt

# We record the 3D densities of both components in a pickle file 
folder = "/Users/luis/Desktop/PROJECTS/EGPE/"
str_Info = f"_Na_{N_atoms_a}_Nb_{N_atoms_b}_{fx}_{fy}_{fz}_{asc_aa/a0}_{asc_bb/a0}_{asc_ab/a0}.pkl"
dens_a = np.abs(psi_a)**2 * N_atoms_a
dens_b = np.abs(psi_b)**2 * N_atoms_b
file_a = folder + "dens_a_" + str_Species + str_Info # Pickle of the values
file_b = folder + "dens_b_" + str_Species + str_Info # Pickle of the values
pickle.dump(dens_a, open(file_a, "wb"))
pickle.dump(dens_b, open(file_b, "wb"))

