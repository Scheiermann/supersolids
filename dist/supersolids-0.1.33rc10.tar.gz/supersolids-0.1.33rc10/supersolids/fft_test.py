#!/usr/bin/env python

import numpy as np
from matplotlib import pyplot as plt
from supersolids.helper import functions


if __name__ == "__main__":
    mu = 0.0
    sigma = 1.0
    res_x = 256
    x0 = -10.0
    x1 = 10.0
    x = np.linspace(x0, x1, res_x)

    box_x_len = np.max(x) - np.min(x)
    dx: float = box_x_len / float(res_x - 1)
    dkx: float = 2.0 * np.pi / box_x_len
    kx: np.ndarray = np.fft.fftfreq(res_x, d=1.0 / (dkx * res_x))
    # kx: np.ndarray = np.fft.fftfreq(res_x, d=dx)

    # print(f"kx:{kx}")
    print(f"dkx:{dkx}")
    # print(len(kx))

    # gauss_x = gauss(x, mu=mu, sigma=sigma)
    gauss_x = functions.psi_gauss_1d(x, x_0=mu)
    norm_x = np.sum(np.abs(gauss_x) ** 2.0) * dx
    print(f"norm_x: {norm_x}")

    gauss_k = np.fft.fft(gauss_x)
    gauss_norm = np.sqrt(2.0 * np.pi) * (1 / gauss_k.size) * (1 / dkx)
    k_normed = gauss_k * gauss_norm
    norm_k = np.sum(np.abs(k_normed) ** 2.0) * dkx
    print(f"norm_k: {norm_k}")

    xx, yy = np.mgrid[x0: x1: complex(0, res_x),
                      x0: x1: complex(0, res_x)]
    gauss_x_2d = functions.psi_gauss_2d(x=xx, y=yy, a_x=4.0, a_y=5.0)
    norm_x_2d = np.sum(np.abs(gauss_x_2d) ** 2.0) * dx * dx
    print(f"norm_x_2d: {norm_x_2d}")

    gauss_k_2d = np.fft.fftn(gauss_x_2d)
    volume_element_2d = np.prod([dkx, dkx])
    gauss_norm_2d = (np.sqrt(2.0 * np.pi) ** 2.0) * (1 / gauss_k_2d.size) * (1 / volume_element_2d)
    gauss_normed_2d = gauss_k_2d * gauss_norm_2d
    norm_k_2d = np.sum(np.abs(gauss_normed_2d) ** 2.0) * volume_element_2d
    print(f"norm_k_2d: {norm_k_2d}")

    xxx, yyy, zzz = np.mgrid[x0: x1: complex(0, res_x),
                             x0: x1: complex(0, res_x),
                             x0: x1: complex(0, res_x)]

    gauss_x_3d = functions.psi_gauss_3d(x=xxx, y=yyy, z=zzz,
                                        a_x=2.0, a_y=1.5, a_z=1.2)
    norm_x_3d = np.sum(np.abs(gauss_x_3d) ** 2.0) * dx * dx * dx
    print(f"norm_x_3d: {norm_x_3d}")

    gauss_k_3d = np.fft.fftn(gauss_x_3d, norm="backward")
    volume_element_3d = np.prod([dkx, dkx, dkx])
    gauss_norm_3d = (np.sqrt(2.0 * np.pi) ** 3.0) * (1 / volume_element_3d) * (1 / gauss_k_3d.size)
    gauss_normed_3d = gauss_k_3d * gauss_norm_3d
    norm_k_3d = np.sum(np.abs(gauss_normed_3d) ** 2.0) * volume_element_3d
    print(f"norm_k_3d: {norm_k_3d}")

    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')

    ax.plot_surface(xx, yy, np.real(gauss_x_2d))
    # plt.plot(x, gauss_x, "o-")
    # plt.plot(kx, gauss_normed, "x-")
    # plt.plot(kx, gauss_sol(kx, a=a), color="red")
    plt.grid()
    plt.show()
