#!/usr/bin/env python
__all__ = ["multi_core",
           "single_core",
           ]
